# DxCyberD - Dos tool
<img src="assest/dx-web.jpg" width="100%" hight="auto">
<div align="left">
  <a href="https://www.youtube.com/channel/UCeN_5wXIV8WW4_vtWbKk8tw" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Youtube&logo=youtube&label=&color=FF0000&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="youtube logo"  />
  </a>
  <a href="https://instagram.com/cyber_d_kdo" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Instagram&logo=instagram&label=&color=E4405F&logoColor=white&labelColor=&style=for-the-badge" height="35" alt="instagram logo"  />
  </a>
</div>


<img align="right" height="150" src="https://i.imgflip.com/65efzo.gif"  />

## Introduction

 Dx tool, also known as DxCyberD, is a dos attack tool made by the Cyber-D army. This tool is specifically designed for ethical hacking purposes to test the security of websites and computer systems. The Dx tool allows users to launch distributed denial of service (DDoS) attacks against targets of their choice, making it an important tool in the realm of cybersecurity.

## Disclaimer

**Usage of Dx for any malicious or unauthorized activities is strictly prohibited.** The developers of Dx and the Cyber-D team are not responsible for any damage, loss, or misuse of this tool. It is the responsibility of the user to comply with all applicable laws and regulations while using this Tool.


### How to Install

Linux commands.

* `sudo apt update`

* `sudo apt upgrade`

* `sudo apt install python3 git`

* `git clone https://github.com/kdo2064/DxCyberD`

* `cd DxCyberD`

Termux commands.

* `pkg update`

* `pkg upgrade`

* `pkg install python3 git -y`

* `git clone https://github.com/kdo2064/DxCyberD`

* `cd DxCyberD`



## Usage
After installing DxCyberD, Here’s the basic command to run DxCyberD:`
* `python3 dx.py` for CLI mood
* `python3 dx-web.py` for GUI mood

## Legal Notice
DxCyberD is intended to be used for ethical and legal purposes, such as security testing and educational purposes. Any misuse or illegal use of this tool is not condoned.
The Cyber-D team and the developers of DxCyberD are not responsible for any illegal, unethical, or unauthorized activities performed by users of this tool.


## Visiter
<img src="https://profile-counter.glitch.me/kdo2064/count.svg" alt="Visitors">
